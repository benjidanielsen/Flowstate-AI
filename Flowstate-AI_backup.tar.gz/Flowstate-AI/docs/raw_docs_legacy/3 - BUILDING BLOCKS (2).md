# 3 \- BUILDING BLOCKS

**Description of end product:**

AI will gather information from 3 documents containing important building blocks to build the best AI-driven CRM system for Network Marketing with automation.

**Built from these 3:**

* “DESCRIPTION \+ CODE \+ BLUEPRINT” [https://docs.google.com/document/d/1uJb051a72h\_wQcmCNwCTljSmgZH1N41BglmhA2XKunQ/edit?tab=t.868rft2s8hmk](https://docs.google.com/document/d/1uJb051a72h_wQcmCNwCTljSmgZH1N41BglmhA2XKunQ/edit?tab=t.868rft2s8hmk)

* “FRAZER METHOD”  
  [https://docs.google.com/document/d/1uJb051a72h\_wQcmCNwCTljSmgZH1N41BglmhA2XKunQ/edit?tab=t.sp6hosvvlqja](https://docs.google.com/document/d/1uJb051a72h_wQcmCNwCTljSmgZH1N41BglmhA2XKunQ/edit?tab=t.sp6hosvvlqja)

* “AI \+ CRM (MODERN)”  
  [https://docs.google.com/document/d/1uJb051a72h\_wQcmCNwCTljSmgZH1N41BglmhA2XKunQ/edit?tab=t.fs3gj3qpyk05](https://docs.google.com/document/d/1uJb051a72h_wQcmCNwCTljSmgZH1N41BglmhA2XKunQ/edit?tab=t.fs3gj3qpyk05)

