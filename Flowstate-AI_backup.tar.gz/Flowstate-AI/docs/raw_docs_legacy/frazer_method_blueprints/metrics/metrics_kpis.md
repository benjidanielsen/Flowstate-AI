# KPIer & målemodell
Funnel (DM→Qualified→Booked→Held→Purchase/Join):
- DM→Qualified rate
- Qualified→Booked rate
- Show rate (Held/Booked)
- Win/Join rate
- AOV/LTV (hvis e‑handel)

Operasjonelt:
- Speed‑to‑lead (sekunder fra DM til første svar)
- SLA etterlevelse (første kontakt < 5 min)
- No‑show rate + rebook recovery
