# Prompt‑tips (vendor‑agnostisk)
- Gi alltid **output‑schema** (JSON‑form) for lett parsing.
- Legg inn **policy/guardrails** (GDPR, samtykke, PII‑minimering).
- Be agenten foreslå **neste steg** + mal, men kreve menneskelig godkjenning i starten.
