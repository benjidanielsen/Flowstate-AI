# dbt‑stil modeller (eksempel – mapp til ditt lager)
