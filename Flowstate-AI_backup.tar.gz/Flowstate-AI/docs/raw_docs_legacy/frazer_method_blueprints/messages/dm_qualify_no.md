Hei {{first_name}}! Takk for interessen 🙌
1) Hva vil du oppnå de neste 3 mnd? 
2) Hvor mye tid har du i uka? 
3) Foretrekker du DM eller telefon? 
(Svarer du ja, kan jeg sende deg en link for en rask prat.)