Hei {{first_name}} – vi savnet deg i dag. Vil du velge et nytt tidspunkt? {{rebook_link}} 
(Ps: Svar med et tall: 1=I morgen, 2=Senere denne uka, 3=Avslutt)